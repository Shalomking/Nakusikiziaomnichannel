define({
  "name": window.site_name,
  "version": "1.0.0",
  "description": false,
  "title": "Administration API Documentation · " + window.site_name,
  "url": window.site_url + "admin",
  "sampleUrl": window.site_url + "admin",
  "template": {
    "showRequiredLabels": true
  },
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2022-02-22T10:51:57.650Z",
    "url": "https://apidocjs.com",
    "version": "0.29.0"
  }
});
