SET CHARACTER SET utf8mb4;

ALTER TABLE `scheduled`
CHANGE `repeat` `repeat` int NOT NULL AFTER `message`;

ALTER TABLE `wa_scheduled`
CHANGE `repeat` `repeat` int NOT NULL AFTER `unique`;